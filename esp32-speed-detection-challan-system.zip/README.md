# ESP32 Speed Detection & Automated Challan System

This project detects vehicle speed using IR sensors and sends SMS/call alerts using Twilio.

## Setup
1. Add WiFi and Twilio credentials in config.h
2. Upload code to ESP32
3. Monitor serial output

## Features
- Speed detection
- Buzzer alert
- SMS and Call notifications
